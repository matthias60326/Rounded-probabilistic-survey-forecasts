********************************************************************************************
******** Uncertainty measures from partially rounded probabilistic forecast surveys ********
********************************************************************************************

This Readme-file provides a short description of the data and code used to derive all results from the main article and the Appendix. 


First, let me briefly explain the folder structure:

1) Code: This folder contains three Stata do-files: "master", "results" and "scenario_A". The "master" do-file can be used to process the raw data from the "Raw"-folder. The "results" do-file takes the processed data from the "Processed"-folder and runs the majority of the empirical analysis. This includes the creation of nearly all tables and figures. Finally, the "scenario_A" do-file runs scenario A from Section 6.1 for the ECB-SPF data.

2) Figures: This folder contains all subfigures from the main article in .pdf format.

3) Processed: This folder contains the processed data that has been created from the "master" do-file. This is the data used in the empirical analysis.

4) Raw: This folder contains the raw data. This includes .csv files for the survey data from the ECB-SPF and the FED-SPF as well as the realizations.

5) Tables: This folder contains the .tex fragments that are required to create the tables from the main article and the Appendix. The various subfolders contains the raw results from the horizon-specific and pooled regressions in .xml format.


Second, let me explain how to execute the data processing and the empirical analysis. This will reproduce all results from our paper.

1) Open the "master" do-file and set the working directory in the ninth row to the "Raw"-folder.

2) Run the entire "master" do-file. This will process the raw data from the "Raw"-folder. The processed data will be stored in the "Processed"-folder. After that, you are done with the "master" do-file.

* Note: The code in lines 254-446 of the "master" do-file can be used to download the data for the individual ECB-SPF waves. Note, however, that the ECB-SPF retroactively includes core inflation forecasts from 2016Q4 onwards, which are not accounted for in our code (those predictions were not included when we originally downloaded the SPF data). Moreover, the code does not take care of the introduction of bins for GDP growth with a width of two percentage points in 2020Q2 (which is outside of our sample period). Similarly, the code used to process the FED-SPF data in lines 1062-1353 of the "master" do-file is only valid for the survey waves considered in our paper. The bins in the FED-SPF may have been further adjusted in later survey waves. For all the reasons discussed here, the two code passages are commented out.

* Note: The loops for the beta distributions may take a while to finish (in particular for the ECB-SPF).

3) Open the "results" do-file and set the working directory in the fourth row to the main folder.

4) Run the entire "results" do-file. This will execute the empirical analysis and create (almost) all TeX fragments and PDFs that you need to create the tables and figures from the main article and the Appendix.

5) Open the "scenario_A" do-file and set the working directory in the eleventh row to the main folder.

6) Run the entire "scenario_A" do-file. This will produce Figure 14 from scenario A in Section 6.1.


If you have any further questions, please do not hesitate to contact me via alexander.glas@fau.de.

Best regards,
Alexander Glas